import { useEffect, useRef } from 'react';
import { app, useApp } from '../state/app.js';
import { cameraApi } from '../scene/cameraApi.js';
import { saveNow, toast } from '../state/actions.js';
import { Icon } from './icons.jsx';

// Press-and-hold button: fires immediately, then repeats while held (mouse, touch or keyboard).
function Hold({ onTick, label, icon, text }) {
  const t = useRef(null);
  const stop = () => {
    clearInterval(t.current);
    t.current = null;
  };
  useEffect(() => stop, []);
  return (
    <button
      className="btn icon-btn hold"
      aria-label={label}
      title={label}
      onPointerDown={(e) => {
        e.preventDefault();
        onTick();
        stop();
        t.current = setInterval(onTick, 45);
      }}
      onPointerUp={stop}
      onPointerLeave={stop}
      onPointerCancel={stop}
      onContextMenu={(e) => e.preventDefault()}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onTick();
        }
      }}
    >
      {icon ? <Icon name={icon} /> : text}
    </button>
  );
}

const VIEWS = [
  ['iso', 'Iso'],
  ['top', 'Top'],
  ['front', 'Front'],
  ['back', 'Back'],
  ['left', 'Left'],
  ['right', 'Right'],
  ['under', 'Under'],
];

export default function BottomBar() {
  const panel = useApp((s) => s.panel);
  const saveState = useApp((s) => s.saveState);
  const STEP = 0.04;

  return (
    <footer className={`bottom ${panel === 'camera' ? 'open' : ''}`} aria-label="Camera controls">
      <button className="sheet-close mobile-only" onClick={() => app.setState({ panel: null })} aria-label="Close panel">
        ×
      </button>

      <div className="bar-group">
        <span className="bar-label">Orbit</span>
        <Hold label="Rotate left" icon="left" onTick={() => cameraApi.orbitBy(-STEP, 0)} />
        <Hold label="Rotate right" icon="right" onTick={() => cameraApi.orbitBy(STEP, 0)} />
        <Hold label="Tilt up (look from above)" icon="up" onTick={() => cameraApi.orbitBy(0, -STEP)} />
        <Hold label="Tilt down (look from below)" icon="down" onTick={() => cameraApi.orbitBy(0, STEP)} />
      </div>

      <div className="bar-group">
        <span className="bar-label">Pan</span>
        <Hold label="Move camera left" icon="left" onTick={() => cameraApi.panBy(-1, 0)} />
        <Hold label="Move camera right" icon="right" onTick={() => cameraApi.panBy(1, 0)} />
        <Hold label="Move camera forward" icon="up" onTick={() => cameraApi.panBy(0, 1)} />
        <Hold label="Move camera backward" icon="down" onTick={() => cameraApi.panBy(0, -1)} />
      </div>

      <div className="bar-group">
        <span className="bar-label">Zoom</span>
        <Hold label="Zoom out" icon="zoomOut" onTick={() => cameraApi.zoomBy(1.025)} />
        <Hold label="Zoom in" icon="zoomIn" onTick={() => cameraApi.zoomBy(0.975)} />
      </div>

      <div className="bar-group views">
        <span className="bar-label">View</span>
        {VIEWS.map(([id, label]) => (
          <button key={id} className="btn text-btn" onClick={() => cameraApi.view(id)}>
            {label}
          </button>
        ))}
      </div>

      <div className="bar-group">
        <button className="btn icon-btn" onClick={() => cameraApi.reset()} title="Reset camera (R)">
          <Icon name="home" />
          <span className="btn-text">Reset view</span>
        </button>
      </div>

      <div className="bar-spacer" />

      <button
        className="btn primary icon-btn"
        onClick={async () => {
          await saveNow();
          if (app.getState().saveState === 'saved') toast('Layout saved');
          else toast('Could not save – try Export JSON', 'error');
        }}
        title="Save layout (Ctrl+S)"
      >
        <Icon name="save" />
        <span className="btn-text">{saveState === 'saved' ? 'Saved' : 'Save layout'}</span>
      </button>
    </footer>
  );
}

import { useEffect, useRef } from 'react';
import { app, useApp, useGrid } from '../state/app.js';
import { PALETTE } from '../core/constants.js';
import { intToHex, parseHexColor } from '../core/color.js';
import {
  setTool,
  pickColor,
  undo,
  redo,
  requestClear,
  toggleGrid,
  addCustomColor,
  removeCustomColor,
} from '../state/actions.js';
import { Icon } from './icons.jsx';

function Swatch({ hex, label, active, onClick }) {
  return (
    <button
      className={`swatch ${active ? 'active' : ''}`}
      style={{ '--c': intToHex(hex) }}
      onClick={onClick}
      aria-label={label}
      aria-pressed={active}
      title={label}
    />
  );
}

function CustomPicker() {
  const color = useApp((s) => s.color);
  const ref = useRef(null);
  useEffect(() => {
    // native "change" fires once when the picker is committed (not on every drag tick)
    const el = ref.current;
    const commit = () => {
      const c = parseHexColor(el.value);
      if (c !== null) addCustomColor(c);
    };
    el.addEventListener('change', commit);
    return () => el.removeEventListener('change', commit);
  }, []);
  return (
    <label className="swatch custom-picker" title="Custom colour" style={{ '--c': intToHex(color) }}>
      <input
        ref={ref}
        type="color"
        value={intToHex(color)}
        aria-label="Custom colour picker"
        onChange={(e) => {
          const c = parseHexColor(e.target.value);
          if (c !== null) pickColor(c);
        }}
      />
      <span className="picker-plus" aria-hidden="true">
        +
      </span>
    </label>
  );
}

export default function Toolbar() {
  const tool = useApp((s) => s.tool);
  const color = useApp((s) => s.color);
  const customs = useApp((s) => s.customColors);
  const showGrid = useApp((s) => s.showGrid);
  const canUndo = useGrid((s) => s.canUndo);
  const canRedo = useGrid((s) => s.canRedo);

  const toolBtn = (id, icon, label, key) => (
    <button
      className={`btn tool ${tool === id ? 'active' : ''}`}
      onClick={() => setTool(id)}
      aria-label={label}
      aria-pressed={tool === id}
      title={`${label} (${key})`}
    >
      <Icon name={icon} />
      <span className="tool-label">{label}</span>
    </button>
  );

  return (
    <aside className="toolbar" aria-label="Drawing tools">
      <div className="tb-group">
        {toolBtn('navigate', 'navigate', 'Move', 'V')}
        {toolBtn('paint', 'paint', 'Paint', 'B')}
        {toolBtn('erase', 'erase', 'Eraser', 'E')}
      </div>

      <div className="tb-group palette" role="group" aria-label="Colour palette">
        {PALETTE.map((p, i) => (
          <Swatch
            key={p.name}
            hex={p.hex}
            label={`${p.name} (${(i + 1) % 10})`}
            active={color === p.hex}
            onClick={() => pickColor(p.hex)}
          />
        ))}
        <CustomPicker />
        {customs.map((c) => (
          <span className="custom-wrap" key={c}>
            <Swatch hex={c} label={`Custom ${intToHex(c)}`} active={color === c} onClick={() => pickColor(c)} />
            {color === c && (
              <button
                className="swatch-x"
                onClick={() => removeCustomColor(c)}
                aria-label={`Remove custom colour ${intToHex(c)}`}
                title="Remove this custom colour"
              >
                ×
              </button>
            )}
          </span>
        ))}
      </div>

      <div className="tb-group">
        <button className="btn tool" onClick={undo} disabled={!canUndo} aria-label="Undo" title="Undo (Ctrl+Z)">
          <Icon name="undo" />
          <span className="tool-label">Undo</span>
        </button>
        <button className="btn tool" onClick={redo} disabled={!canRedo} aria-label="Redo" title="Redo (Ctrl+Y)">
          <Icon name="redo" />
          <span className="tool-label">Redo</span>
        </button>
        <button className="btn tool danger" onClick={requestClear} aria-label="Clear grid" title="Clear entire grid">
          <Icon name="trash" />
          <span className="tool-label">Clear</span>
        </button>
        <button
          className={`btn tool ${showGrid ? 'active' : ''}`}
          onClick={toggleGrid}
          aria-label="Toggle grid lines"
          aria-pressed={showGrid}
          title="Grid lines (G)"
        >
          <Icon name="grid" />
          <span className="tool-label">Grid</span>
        </button>
      </div>
    </aside>
  );
}

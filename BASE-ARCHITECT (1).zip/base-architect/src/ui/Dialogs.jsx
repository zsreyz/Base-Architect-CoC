import { useEffect, useRef, useState } from 'react';
import { app, useApp, useGrid } from '../state/app.js';
import { fmt } from '../core/stats.js';
import {
  closeDialog,
  confirmClear,
  deleteLayoutById,
  duplicateLayout,
  exportCurrentJson,
  exportJsonById,
  exportPng,
  importFile,
  newLayout,
  openLayout,
  refreshLayouts,
  renameLayout,
  saveNow,
  toast,
} from '../state/actions.js';
import { Icon } from './icons.jsx';

function Modal({ title, onClose, children, wide }) {
  const ref = useRef(null);
  useEffect(() => {
    const prev = document.activeElement;
    if (!ref.current?.contains(document.activeElement)) ref.current?.focus();
    const onKey = (e) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'Tab') {
        // keep focus inside the dialog
        const f = ref.current.querySelectorAll('button:not([disabled]), input, [tabindex="0"]');
        if (!f.length) return;
        const first = f[0];
        const lastEl = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          lastEl.focus();
        } else if (!e.shiftKey && document.activeElement === lastEl) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('keydown', onKey);
      prev?.focus?.();
    };
  }, [onClose]);
  return (
    <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div
        className={`modal ${wide ? 'wide' : ''}`}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        ref={ref}
        tabIndex={-1}
      >
        <div className="modal-head">
          <h2>{title}</h2>
          <button className="btn icon-btn" onClick={onClose} aria-label="Close dialog">
            <Icon name="close" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

function ConfirmClear() {
  const coloured = useGrid((s) => s.coloured);
  return (
    <Modal title="Clear entire grid?" onClose={closeDialog}>
      <p className="modal-text">
        This removes all <b>{fmt(coloured)}</b> coloured cells. You can bring them back afterwards with Undo.
      </p>
      <div className="modal-actions">
        <button className="btn" onClick={closeDialog} autoFocus>
          Cancel
        </button>
        <button className="btn danger-fill" onClick={confirmClear}>
          Clear grid
        </button>
      </div>
    </Modal>
  );
}

function ConfirmDelete({ id, name }) {
  return (
    <Modal title="Delete layout?" onClose={() => app.setState({ dialog: { type: 'layouts' } })}>
      <p className="modal-text">
        “<b>{name}</b>” will be permanently deleted from this browser. Export it first if you may need it later.
      </p>
      <div className="modal-actions">
        <button className="btn" autoFocus onClick={() => app.setState({ dialog: { type: 'layouts' } })}>
          Cancel
        </button>
        <button
          className="btn danger-fill"
          onClick={async () => {
            await deleteLayoutById(id);
            app.setState({ dialog: { type: 'layouts' } });
          }}
        >
          Delete
        </button>
      </div>
    </Modal>
  );
}

function Row({ l, isCurrent }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(l.name);
  const commit = async () => {
    setEditing(false);
    if (val.trim() && val.trim() !== l.name) await renameLayout(l.id, val);
    else setVal(l.name);
  };
  return (
    <li className={`layout-row ${isCurrent ? 'current' : ''}`}>
      <div className="layout-main">
        {editing ? (
          <input
            className="name-input"
            value={val}
            autoFocus
            maxLength={60}
            aria-label="Rename layout"
            onChange={(e) => setVal(e.target.value)}
            onBlur={commit}
            onKeyDown={(e) => {
              if (e.key === 'Enter') e.currentTarget.blur();
              if (e.key === 'Escape') {
                e.stopPropagation();
                setVal(l.name);
                setEditing(false);
              }
            }}
          />
        ) : (
          <div className="layout-name">
            {l.name} {isCurrent && <span className="badge">Open</span>}
          </div>
        )}
        <div className="muted small">
          {fmt(l.coloured)} / 1,936 coloured · {new Date(l.updatedAt).toLocaleString()}
        </div>
      </div>
      <div className="layout-actions">
        {!isCurrent && (
          <button className="btn text-btn" onClick={() => openLayout(l.id)}>
            Open
          </button>
        )}
        <button className="btn icon-btn" onClick={() => setEditing(true)} aria-label={`Rename ${l.name}`} title="Rename">
          <Icon name="edit" size={18} />
        </button>
        <button className="btn icon-btn" onClick={() => duplicateLayout(l.id)} aria-label={`Duplicate ${l.name}`} title="Duplicate">
          <Icon name="copy" size={18} />
        </button>
        <button className="btn icon-btn" onClick={() => exportJsonById(l.id)} aria-label={`Export ${l.name} as JSON`} title="Export JSON">
          <Icon name="download" size={18} />
        </button>
        <button
          className="btn icon-btn danger"
          onClick={() => app.setState({ dialog: { type: 'delete', id: l.id, name: l.name } })}
          aria-label={`Delete ${l.name}`}
          title="Delete"
        >
          <Icon name="trash" size={18} />
        </button>
      </div>
    </li>
  );
}

function Layouts() {
  const layouts = useApp((s) => s.layouts);
  const currentId = useApp((s) => s.currentId);
  const file = useRef(null);
  useEffect(() => {
    refreshLayouts();
  }, []);
  return (
    <Modal title="Layouts" onClose={closeDialog} wide>
      <div className="modal-toolbar">
        <button className="btn" onClick={newLayout}>
          <Icon name="plus" size={18} /> New layout
        </button>
        <button className="btn" onClick={() => file.current.click()}>
          <Icon name="upload" size={18} /> Import JSON
        </button>
        <button className="btn" onClick={exportCurrentJson}>
          <Icon name="download" size={18} /> Export JSON
        </button>
        <button className="btn" onClick={exportPng}>
          <Icon name="image" size={18} /> Export PNG
        </button>
        <button
          className="btn"
          onClick={async () => {
            await saveNow();
            await refreshLayouts();
            toast('Layout saved');
          }}
        >
          <Icon name="save" size={18} /> Save now
        </button>
        <input
          ref={file}
          type="file"
          accept=".json,application/json"
          hidden
          onChange={async (e) => {
            const f = e.target.files?.[0];
            e.target.value = '';
            await importFile(f);
          }}
        />
      </div>
      <ul className="layout-list">
        {layouts.map((l) => (
          <Row key={l.id} l={l} isCurrent={l.id === currentId} />
        ))}
      </ul>
      <p className="muted small">
        Layouts are stored in this browser (IndexedDB) and auto-saved as you paint. Export JSON to back them up or
        move them to another device.
      </p>
    </Modal>
  );
}

export function Dialogs() {
  const dialog = useApp((s) => s.dialog);
  if (!dialog) return null;
  if (dialog.type === 'clear') return <ConfirmClear />;
  if (dialog.type === 'delete') return <ConfirmDelete id={dialog.id} name={dialog.name} />;
  if (dialog.type === 'layouts') return <Layouts />;
  return null;
}

export function Toast() {
  const t = useApp((s) => s.toast);
  if (!t) return null;
  return (
    <div className={`toast ${t.kind}`} role="status" key={t.id}>
      {t.message}
    </div>
  );
}

import { app, useApp, useGrid } from '../state/app.js';
import { stats, formatPct, fmt } from '../core/stats.js';
import { COLS, ROWS } from '../core/constants.js';
import { setName, openDialog } from '../state/actions.js';
import { Icon } from './icons.jsx';

const SAVE_LABEL = { saved: 'Saved', dirty: 'Unsaved…', saving: 'Saving…', error: 'Save failed' };

export default function TopBar() {
  const coloured = useGrid((s) => s.coloured);
  const name = useApp((s) => s.name);
  const saveState = useApp((s) => s.saveState);
  const panel = useApp((s) => s.panel);
  const st = stats(coloured);
  const togglePanel = (p) => app.setState({ panel: app.getState().panel === p ? null : p });

  return (
    <header className="topbar">
      <div className="brand">
        <span className="logo" aria-hidden="true">
          <svg viewBox="0 0 32 32" width="22" height="22">
            <path d="M5 5h22v22H5zM5 12.3h22M5 19.7h22M12.3 5v22M19.7 5v22" fill="none" stroke="currentColor" strokeWidth="1.8" />
          </svg>
        </span>
        <span className="brand-name">BASE ARCHITECT</span>
      </div>

      <div className="chips">
        <span className="chip" title="Grid dimensions">
          {COLS} × {ROWS}
        </span>
        <span className="chip" title="Coloured cells" aria-live="polite">
          <span className="chip-label">Coloured</span> <b>{fmt(st.coloured)}</b>
          <span className="dim"> / {fmt(st.total)}</span>
        </span>
        <span className="chip" title="Completion">
          <span className="chip-label">Done</span> <b>{formatPct(st.pct)}</b>
        </span>
      </div>

      <div className="topbar-right">
        <input
          className="name-input"
          value={name}
          maxLength={60}
          aria-label="Layout name"
          onChange={(e) => setName(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.blur()}
        />
        <span className={`save-state ${saveState}`} role="status">
          {SAVE_LABEL[saveState]}
        </span>
        <button className="btn icon-btn" onClick={() => openDialog({ type: 'layouts' })} aria-label="Layouts">
          <Icon name="folder" />
          <span className="btn-text">Layouts</span>
        </button>
        <button
          className={`btn icon-btn mobile-only ${panel === 'stats' ? 'active' : ''}`}
          onClick={() => togglePanel('stats')}
          aria-label="Statistics panel"
          aria-pressed={panel === 'stats'}
        >
          <Icon name="chart" />
        </button>
        <button
          className={`btn icon-btn mobile-only ${panel === 'camera' ? 'active' : ''}`}
          onClick={() => togglePanel('camera')}
          aria-label="Camera controls"
          aria-pressed={panel === 'camera'}
        >
          <Icon name="camera" />
        </button>
      </div>
    </header>
  );
}

import { useEffect } from 'react';
import { app } from '../state/app.js';
import { PALETTE } from '../core/constants.js';
import { cameraApi } from '../scene/cameraApi.js';
import { setTool, pickColor, undo, redo, toggleGrid, saveNow, toast } from '../state/actions.js';

const typing = (t) =>
  t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable);

export default function useShortcuts() {
  useEffect(() => {
    const down = (e) => {
      if (typing(e.target) && !(e.target.type === 'color' && e.key !== ' ')) return;
      if (app.getState().dialog) return;
      const k = e.key.toLowerCase();
      const mod = e.ctrlKey || e.metaKey;

      if (mod) {
        if (k === 'z') {
          e.preventDefault();
          e.shiftKey ? redo() : undo();
        } else if (k === 'y') {
          e.preventDefault();
          redo();
        } else if (k === 's') {
          e.preventDefault();
          saveNow().then(() => toast('Layout saved'));
        }
        return;
      }
      if (e.altKey) return;

      if (e.key === ' ') {
        if (e.target.tagName === 'BUTTON') return; // let Space activate focused buttons
        e.preventDefault();
        if (!e.repeat) app.setState({ spaceDown: true });
        return;
      }
      if (k === 'b') setTool('paint');
      else if (k === 'e') setTool('erase');
      else if (k === 'v' || k === 'h') setTool('navigate');
      else if (k === 'g') toggleGrid();
      else if (k === 'r') cameraApi.reset();
      else if (e.key === '+' || e.key === '=') cameraApi.zoomBy(0.9);
      else if (e.key === '-' || e.key === '_') cameraApi.zoomBy(1.1);
      else if (e.key === 'ArrowLeft') (e.preventDefault(), cameraApi.panBy(-1.5, 0));
      else if (e.key === 'ArrowRight') (e.preventDefault(), cameraApi.panBy(1.5, 0));
      else if (e.key === 'ArrowUp') (e.preventDefault(), cameraApi.panBy(0, 1.5));
      else if (e.key === 'ArrowDown') (e.preventDefault(), cameraApi.panBy(0, -1.5));
      else if (/^[0-9]$/.test(e.key)) {
        const i = (parseInt(e.key, 10) + 9) % 10; // 1..9 -> 0..8, 0 -> 9
        if (PALETTE[i]) pickColor(PALETTE[i].hex);
      }
    };
    const up = (e) => {
      if (e.key === ' ') app.setState({ spaceDown: false });
    };
    const blur = () => app.setState({ spaceDown: false });
    // After clicking a toolbar button with the mouse, drop its focus so holding Space
    // means "move camera" instead of re-pressing that button.
    const release = (e) => {
      const b = e.pointerType === 'mouse' && e.target.closest && e.target.closest('.toolbar button, .bottom button');
      if (b) setTimeout(() => b.blur(), 0);
    };
    window.addEventListener('pointerup', release);
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    window.addEventListener('blur', blur);
    return () => {
      window.removeEventListener('keydown', down);
      window.removeEventListener('keyup', up);
      window.removeEventListener('blur', blur);
      window.removeEventListener('pointerup', release);
    };
  }, []);
}

import { grid, app, useApp, useGrid } from '../state/app.js';
import { stats, formatPct, fmt } from '../core/stats.js';
import { cellName } from '../core/coords.js';
import { colorName, intToHex } from '../core/color.js';
import { EMPTY, EMPTY_HEX } from '../core/constants.js';

export default function StatsPanel() {
  const coloured = useGrid((s) => s.coloured);
  useGrid((s) => s.revision); // re-read the selected cell's colour after every edit
  const color = useApp((s) => s.color);
  const tool = useApp((s) => s.tool);
  const selected = useApp((s) => s.selected);
  const hover = useApp((s) => s.hover);
  const panel = useApp((s) => s.panel);
  const st = stats(coloured);

  const idx = selected >= 0 ? selected : hover;
  const cellVal = idx >= 0 ? grid.cells[idx] : null;

  return (
    <aside className={`right ${panel === 'stats' ? 'open' : ''}`} aria-label="Statistics">
      <button className="sheet-close mobile-only" onClick={() => app.setState({ panel: null })} aria-label="Close panel">
        ×
      </button>

      <section className="card">
        <h2>Grid statistics</h2>
        <dl className="stat-list" aria-live="polite">
          <div>
            <dt>Total cells</dt>
            <dd>{fmt(st.total)}</dd>
          </div>
          <div>
            <dt>Coloured cells</dt>
            <dd>
              {fmt(st.coloured)} <span className="dim">/ {fmt(st.total)}</span>
            </dd>
          </div>
          <div>
            <dt>Empty cells</dt>
            <dd>{fmt(st.empty)}</dd>
          </div>
          <div>
            <dt>Completion</dt>
            <dd>{formatPct(st.pct)}</dd>
          </div>
        </dl>
        <div
          className="progress"
          role="progressbar"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={Number(st.pct.toFixed(2))}
          aria-label="Completion"
        >
          <div className="progress-fill" style={{ width: `${st.pct}%` }} />
        </div>
      </section>

      <section className="card">
        <h2>{selected >= 0 ? 'Selected cell' : 'Cell under cursor'}</h2>
        {idx >= 0 ? (
          <dl className="stat-list">
            <div>
              <dt>Coordinate</dt>
              <dd>{cellName(idx)}</dd>
            </div>
            <div>
              <dt>Current colour</dt>
              <dd className="with-swatch">
                <i
                  className={`dot ${cellVal === EMPTY ? 'empty' : ''}`}
                  style={{ background: intToHex(cellVal === EMPTY ? EMPTY_HEX : cellVal) }}
                />
                {colorName(cellVal)}
              </dd>
            </div>
          </dl>
        ) : (
          <p className="muted">Tap or hover a cell to see its coordinate (A1 – AR44).</p>
        )}
      </section>

      <section className="card">
        <h2>Active colour</h2>
        <div className="active-color">
          <i className="big-dot" style={{ background: intToHex(color) }} />
          <div>
            <div className="ac-name">{colorName(color)}</div>
            <div className="muted mono">{intToHex(color).toUpperCase()}</div>
          </div>
        </div>
        <p className="muted small">
          Tool: <b>{tool === 'navigate' ? 'Move camera' : tool === 'paint' ? 'Paint' : 'Eraser'}</b>
        </p>
      </section>
    </aside>
  );
}

import { TOTAL, EMPTY } from './constants.js';
import { createStore } from './createStore.js';

const HISTORY_LIMIT = 100;

/**
 * The single source of truth for the 44 x 44 grid.
 *
 * - `cells` is an Int32Array: EMPTY (-1) or a 24-bit colour. One slot per cell, so a
 *   cell can only ever hold one colour.
 * - `count` is maintained incrementally on every real change (never on a no-op), and
 *   `countActual()` recomputes it from the data so tests can prove they always match.
 * - Edits made between beginStroke() and endStroke() form ONE undo step.
 */
export class Grid {
  constructor() {
    this.cells = new Int32Array(TOTAL).fill(EMPTY);
    this.count = 0;
    this.undoStack = [];
    this.redoStack = [];
    this.stroke = null; // Map<index, previousValue> while a stroke is open
    this.listeners = new Set();
    this.revision = 0;
    this.status = createStore({ coloured: 0, canUndo: false, canRedo: false, revision: 0 });
  }

  /** fn(indices | null). null means "everything changed". Returns an unsubscribe. */
  onChange(fn) {
    this.listeners.add(fn);
    return () => {
      this.listeners.delete(fn);
    };
  }

  _emit(indices) {
    this.revision++;
    for (const fn of this.listeners) fn(indices);
    this._publish();
  }

  _publish() {
    this.status.setState({
      coloured: this.count,
      canUndo: this.undoStack.length > 0,
      canRedo: this.redoStack.length > 0,
      revision: this.revision,
    });
  }

  // Writes one cell and keeps the counter exact. Returns true only if something changed.
  _write(i, v) {
    const prev = this.cells[i];
    if (prev === v) return false;
    if (prev === EMPTY) this.count++;
    else if (v === EMPTY) this.count--;
    this.cells[i] = v;
    return true;
  }

  countActual() {
    let n = 0;
    for (let i = 0; i < TOTAL; i++) if (this.cells[i] !== EMPTY) n++;
    return n;
  }

  beginStroke() {
    if (this.stroke) this.endStroke();
    this.stroke = new Map();
  }

  /** Paint (v = colour) or erase (v = EMPTY) one cell. Returns true if it changed. */
  paint(i, v) {
    if (!Number.isInteger(i) || i < 0 || i >= TOTAL) return false;
    const own = !this.stroke;
    if (own) this.beginStroke();
    const prev = this.cells[i];
    const changed = this._write(i, v);
    if (changed) {
      if (!this.stroke.has(i)) this.stroke.set(i, prev);
      this._emit([i]);
    }
    if (own) this.endStroke();
    return changed;
  }

  endStroke() {
    const s = this.stroke;
    this.stroke = null;
    if (!s) return;
    const entries = [];
    for (const [i, prev] of s) {
      const next = this.cells[i];
      if (prev !== next) entries.push([i, prev, next]);
    }
    if (entries.length) {
      this.undoStack.push(entries);
      if (this.undoStack.length > HISTORY_LIMIT) this.undoStack.shift();
      this.redoStack.length = 0;
    }
    this._publish();
  }

  /** Abandon the open stroke and restore every cell it touched (used for accidental touches). */
  cancelStroke() {
    const s = this.stroke;
    this.stroke = null;
    if (!s) return;
    const changed = [];
    for (const [i, prev] of s) {
      if (this._write(i, prev)) changed.push(i);
    }
    if (changed.length) this._emit(changed);
    else this._publish();
  }

  undo() {
    if (this.stroke) this.endStroke();
    const entries = this.undoStack.pop();
    if (!entries) return false;
    const changed = [];
    for (const [i, prev] of entries) {
      this._write(i, prev);
      changed.push(i);
    }
    this.redoStack.push(entries);
    this._emit(changed);
    return true;
  }

  redo() {
    if (this.stroke) this.endStroke();
    const entries = this.redoStack.pop();
    if (!entries) return false;
    const changed = [];
    for (const [i, , next] of entries) {
      this._write(i, next);
      changed.push(i);
    }
    this.undoStack.push(entries);
    this._emit(changed);
    return true;
  }

  /** Erase everything as one undoable step. */
  clear() {
    if (this.stroke) this.endStroke();
    const entries = [];
    for (let i = 0; i < TOTAL; i++) {
      if (this.cells[i] !== EMPTY) entries.push([i, this.cells[i], EMPTY]);
    }
    if (!entries.length) return false;
    for (const [i] of entries) this._write(i, EMPTY);
    this.undoStack.push(entries);
    if (this.undoStack.length > HISTORY_LIMIT) this.undoStack.shift();
    this.redoStack.length = 0;
    this._emit(null);
    return true;
  }

  /** Replace the whole grid (open / import). History is reset. */
  load(cells) {
    if (!(cells instanceof Int32Array) || cells.length !== TOTAL) {
      throw new Error('Grid.load expects an Int32Array of 1,936 cells');
    }
    this.stroke = null;
    this.cells.set(cells);
    this.count = this.countActual();
    this.undoStack = [];
    this.redoStack = [];
    this._emit(null);
  }

  snapshot() {
    return this.cells.slice();
  }
}

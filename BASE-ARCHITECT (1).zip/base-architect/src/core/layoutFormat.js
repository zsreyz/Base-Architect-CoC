import { COLS, ROWS, TOTAL, EMPTY, APP_NAME } from './constants.js';
import { cellName, parseCoord } from './coords.js';
import { intToHex, parseHexColor } from './color.js';

export const FORMAT = 'base-architect-layout';
export const FORMAT_VERSION = 1;
const MAX_IMPORT_BYTES = 5 * 1024 * 1024;

/** Layout object (in-memory) -> JSON-serialisable export object. Lists ALL 1,936 cells. */
export function toExport(layout) {
  const cells = new Array(TOTAL);
  let coloured = 0;
  for (let i = 0; i < TOTAL; i++) {
    const v = layout.cells[i];
    if (v !== EMPTY) coloured++;
    cells[i] = { coord: cellName(i), color: v === EMPTY ? null : intToHex(v) };
  }
  return {
    format: FORMAT,
    version: FORMAT_VERSION,
    app: APP_NAME,
    name: layout.name,
    grid: { columns: COLS, rows: ROWS, totalCells: TOTAL },
    metadata: {
      createdAt: layout.createdAt,
      updatedAt: layout.updatedAt,
      exportedAt: Date.now(),
      colouredCells: coloured,
      emptyCells: TOTAL - coloured,
      completionPercent: Number(((coloured / TOTAL) * 100).toFixed(2)),
    },
    cells,
  };
}

/**
 * Parse + validate imported JSON text. Never throws: returns { ok:true, layout } or
 * { ok:false, error }. Layout: { name, cells:Int32Array, createdAt, updatedAt }.
 */
export function parseImport(text) {
  try {
    if (typeof text !== 'string') return fail('Not a text file.');
    if (text.length > MAX_IMPORT_BYTES) return fail('File is too large (max 5 MB).');
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      return fail('File is not valid JSON.');
    }
    if (!data || typeof data !== 'object' || Array.isArray(data)) return fail('Unexpected JSON structure.');
    if (data.format !== FORMAT) return fail('This is not a BASE ARCHITECT layout file.');
    if (!Number.isInteger(data.version) || data.version > FORMAT_VERSION) {
      return fail('Unsupported layout version.');
    }
    const g = data.grid;
    if (!g || g.columns !== COLS || g.rows !== ROWS) return fail(`Grid must be ${COLS} × ${ROWS}.`);
    if (!Array.isArray(data.cells)) return fail('Missing cell list.');
    if (data.cells.length > TOTAL) return fail('Too many cells in file.');

    const cells = new Int32Array(TOTAL).fill(EMPTY);
    const seen = new Set();
    for (const entry of data.cells) {
      if (!entry || typeof entry !== 'object') return fail('A cell entry is malformed.');
      const p = parseCoord(entry.coord);
      if (!p) return fail(`Invalid cell coordinate: ${String(entry.coord).slice(0, 12)}`);
      if (seen.has(p.index)) return fail(`Duplicate cell: ${entry.coord}`);
      seen.add(p.index);
      if (entry.color === null || entry.color === undefined) continue;
      const c = parseHexColor(entry.color);
      if (c === null) return fail(`Invalid colour at ${entry.coord}.`);
      cells[p.index] = c;
    }

    const name =
      typeof data.name === 'string' && data.name.trim() ? data.name.trim().slice(0, 60) : 'Imported layout';
    const md = data.metadata && typeof data.metadata === 'object' ? data.metadata : {};
    const now = Date.now();
    return {
      ok: true,
      layout: {
        name,
        cells,
        createdAt: Number.isFinite(md.createdAt) ? md.createdAt : now,
        updatedAt: now,
      },
    };
  } catch {
    return fail('Could not read the file.');
  }
}

function fail(error) {
  return { ok: false, error };
}

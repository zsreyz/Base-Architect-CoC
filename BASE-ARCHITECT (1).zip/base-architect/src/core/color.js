import { PALETTE, EMPTY } from './constants.js';

export const intToHex = (n) => '#' + (n & 0xffffff).toString(16).padStart(6, '0');

/** "#aabbcc" or "aabbcc" -> integer, anything else -> null */
export function parseHexColor(s) {
  if (typeof s !== 'string') return null;
  const m = /^#?([0-9a-fA-F]{6})$/.exec(s.trim());
  return m ? parseInt(m[1], 16) : null;
}

export function colorName(n) {
  if (n === EMPTY) return 'Empty';
  const p = PALETTE.find((c) => c.hex === n);
  return p ? p.name : 'Custom ' + intToHex(n).toUpperCase();
}

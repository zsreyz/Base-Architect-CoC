export const COLS = 44;
export const ROWS = 44;
export const TOTAL = COLS * ROWS; // 1,936
export const EMPTY = -1; // value stored for an uncoloured cell
export const APP_NAME = 'BASE ARCHITECT';

// Colours are stored as 24-bit integers (0xRRGGBB). Black is 0, so EMPTY must be -1.
export const PALETTE = [
  { name: 'Red', hex: 0xe5484d },
  { name: 'Blue', hex: 0x3b82f6 },
  { name: 'Green', hex: 0x30a46c },
  { name: 'Yellow', hex: 0xf5d90a },
  { name: 'Orange', hex: 0xf76b15 },
  { name: 'Purple', hex: 0x8e4ec6 },
  { name: 'White', hex: 0xffffff },
  { name: 'Black', hex: 0x000000 },
  { name: 'Grey', hex: 0x8b8d98 },
  { name: 'Brown', hex: 0x7c4a2d },
];

export const EMPTY_HEX = 0x2a2f37; // how an uncoloured cell is drawn

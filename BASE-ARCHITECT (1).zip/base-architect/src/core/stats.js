import { TOTAL } from './constants.js';

export function stats(coloured) {
  return { total: TOTAL, coloured, empty: TOTAL - coloured, pct: (coloured / TOTAL) * 100 };
}

/** 0 -> "0%", 200/1936 -> "10.33%", all -> "100%" */
export function formatPct(p) {
  return Number.isInteger(p) ? `${p}%` : `${p.toFixed(2)}%`;
}

export const fmt = (n) => n.toLocaleString('en-US');

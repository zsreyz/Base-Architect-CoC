import { COLS, ROWS } from './constants.js';

/** 0 -> "A", 25 -> "Z", 26 -> "AA", 43 -> "AR" */
export function colLabel(c) {
  let n = c;
  let s = '';
  do {
    s = String.fromCharCode(65 + (n % 26)) + s;
    n = Math.floor(n / 26) - 1;
  } while (n >= 0);
  return s;
}

/** cell index (0..1935) -> "C12". Row 0 is "1", column 0 is "A". */
export function cellName(index) {
  return colLabel(index % COLS) + (Math.floor(index / COLS) + 1);
}

/** "AR44" -> { col, row, index } or null when invalid / out of range */
export function parseCoord(str) {
  if (typeof str !== 'string') return null;
  const m = /^([A-Z]{1,2})([1-9][0-9]?)$/.exec(str.trim().toUpperCase());
  if (!m) return null;
  let v = 0;
  for (const ch of m[1]) v = v * 26 + (ch.charCodeAt(0) - 64);
  const col = v - 1;
  const row = parseInt(m[2], 10) - 1;
  if (col < 0 || col >= COLS || row < 0 || row >= ROWS) return null;
  return { col, row, index: row * COLS + col };
}

/**
 * Cells on the straight line from `from` to `to` (Bresenham), excluding `from`
 * and including `to`. Used so fast drags never leave gaps between pointer events.
 */
export function lineCells(from, to) {
  let x0 = from % COLS;
  let y0 = Math.floor(from / COLS);
  const x1 = to % COLS;
  const y1 = Math.floor(to / COLS);
  const dx = Math.abs(x1 - x0);
  const dy = Math.abs(y1 - y0);
  const sx = x0 < x1 ? 1 : -1;
  const sy = y0 < y1 ? 1 : -1;
  let err = dx - dy;
  const out = [];
  while (x0 !== x1 || y0 !== y1) {
    const e2 = 2 * err;
    if (e2 > -dy) {
      err -= dy;
      x0 += sx;
    }
    if (e2 < dx) {
      err += dx;
      y0 += sy;
    }
    out.push(y0 * COLS + x0);
  }
  return out;
}

import { TOTAL, EMPTY } from './constants.js';

// IndexedDB persistence with an in-memory fallback if the browser blocks storage
// (private mode, etc). Layout record: { id, name, cells:Int32Array, createdAt, updatedAt }.
const DB_NAME = 'base-architect';
const STORE = 'layouts';
const META = 'meta';

let dbPromise = null;
const memory = { layouts: new Map(), meta: new Map() };
let useMemory = typeof indexedDB === 'undefined';

function openDb() {
  if (useMemory) return Promise.resolve(null);
  if (!dbPromise) {
    dbPromise = new Promise((resolve) => {
      try {
        const req = indexedDB.open(DB_NAME, 1);
        req.onupgradeneeded = () => {
          const db = req.result;
          if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: 'id' });
          if (!db.objectStoreNames.contains(META)) db.createObjectStore(META);
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => {
          useMemory = true;
          resolve(null);
        };
        req.onblocked = () => {
          useMemory = true;
          resolve(null);
        };
      } catch {
        useMemory = true;
        resolve(null);
      }
    });
  }
  return dbPromise;
}

function run(storeName, mode, fn) {
  return openDb().then(
    (db) =>
      new Promise((resolve, reject) => {
        if (!db) return reject(new Error('no-db'));
        const tx = db.transaction(storeName, mode);
        const st = tx.objectStore(storeName);
        let result;
        const req = fn(st);
        if (req) req.onsuccess = () => (result = req.result);
        tx.oncomplete = () => resolve(result);
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error);
      }),
  );
}

async function withFallback(idbOp, memOp) {
  if (!useMemory) {
    try {
      return await idbOp();
    } catch (e) {
      if (e && e.message !== 'no-db') useMemory = true;
      useMemory = true;
    }
  }
  return memOp();
}

// Records are stored as plain arrays to be safe across structured-clone implementations.
const pack = (l) => ({ ...l, cells: Array.from(l.cells) });
function unpack(r) {
  if (!r || !Array.isArray(r.cells) || r.cells.length !== TOTAL) return null;
  return { ...r, cells: Int32Array.from(r.cells) };
}

export function newId() {
  return 'l_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

export function blankLayout(name = 'Untitled base') {
  const now = Date.now();
  return { id: newId(), name, cells: new Int32Array(TOTAL).fill(EMPTY), createdAt: now, updatedAt: now };
}

export const listLayouts = () =>
  withFallback(
    async () => {
      const rows = await run(STORE, 'readonly', (s) => s.getAll());
      return (rows || []).map(unpack).filter(Boolean);
    },
    () => [...memory.layouts.values()].map((l) => ({ ...l, cells: l.cells.slice() })),
  ).then((all) => all.sort((a, b) => b.updatedAt - a.updatedAt));

export const getLayout = (id) =>
  withFallback(
    async () => unpack(await run(STORE, 'readonly', (s) => s.get(id))),
    () => {
      const l = memory.layouts.get(id);
      return l ? { ...l, cells: l.cells.slice() } : null;
    },
  );

export const putLayout = (layout) =>
  withFallback(
    async () => {
      await run(STORE, 'readwrite', (s) => s.put(pack(layout)));
    },
    () => {
      memory.layouts.set(layout.id, { ...layout, cells: layout.cells.slice() });
    },
  );

export const deleteLayout = (id) =>
  withFallback(
    async () => {
      await run(STORE, 'readwrite', (s) => s.delete(id));
    },
    () => {
      memory.layouts.delete(id);
    },
  );

export const getMeta = (key) =>
  withFallback(
    () => run(META, 'readonly', (s) => s.get(key)),
    () => memory.meta.get(key),
  );

export const setMeta = (key, value) =>
  withFallback(
    async () => {
      await run(META, 'readwrite', (s) => s.put(value, key));
    },
    () => {
      memory.meta.set(key, value);
    },
  );

export function isPersistent() {
  return !useMemory;
}

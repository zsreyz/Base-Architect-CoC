import { COLS, ROWS, TOTAL, EMPTY, EMPTY_HEX, APP_NAME } from './constants.js';
import { colLabel } from './coords.js';
import { intToHex } from './color.js';

/** Renders a flat top-down PNG of the grid (with coordinates) and resolves to a Blob. */
export function exportPngBlob(cells, name) {
  const CELL = 28;
  const M = 44; // margin for coordinate labels
  const HEAD = 52;
  const W = COLS * CELL + M * 2;
  const H = ROWS * CELL + M * 2 + HEAD;
  const canvas = document.createElement('canvas');
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext('2d');

  ctx.fillStyle = '#16181c';
  ctx.fillRect(0, 0, W, H);

  let coloured = 0;
  for (let i = 0; i < TOTAL; i++) if (cells[i] !== EMPTY) coloured++;

  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#e6e8eb';
  ctx.font = '700 20px system-ui, sans-serif';
  ctx.textAlign = 'left';
  ctx.fillText(`${APP_NAME}  ·  ${name}`, M, 26);
  ctx.fillStyle = '#8b92a0';
  ctx.font = '500 14px system-ui, sans-serif';
  ctx.textAlign = 'right';
  ctx.fillText(
    `${coloured.toLocaleString('en-US')} / ${TOTAL.toLocaleString('en-US')} coloured`,
    W - M,
    26,
  );

  const ox = M;
  const oy = HEAD + M;

  for (let i = 0; i < TOTAL; i++) {
    const x = ox + (i % COLS) * CELL;
    const y = oy + Math.floor(i / COLS) * CELL;
    ctx.fillStyle = cells[i] === EMPTY ? intToHex(EMPTY_HEX) : intToHex(cells[i]);
    ctx.fillRect(x, y, CELL, CELL);
  }

  ctx.strokeStyle = '#4b525e';
  ctx.lineWidth = 1;
  ctx.beginPath();
  for (let i = 0; i <= COLS; i++) {
    ctx.moveTo(ox + i * CELL + 0.5, oy);
    ctx.lineTo(ox + i * CELL + 0.5, oy + ROWS * CELL);
  }
  for (let j = 0; j <= ROWS; j++) {
    ctx.moveTo(ox, oy + j * CELL + 0.5);
    ctx.lineTo(ox + COLS * CELL, oy + j * CELL + 0.5);
  }
  ctx.stroke();
  ctx.strokeStyle = '#8f98a8';
  ctx.lineWidth = 2;
  ctx.strokeRect(ox, oy, COLS * CELL, ROWS * CELL);

  ctx.fillStyle = '#a3abb8';
  ctx.font = '600 13px system-ui, sans-serif';
  ctx.textAlign = 'center';
  for (let c = 0; c < COLS; c++) {
    const x = ox + c * CELL + CELL / 2;
    ctx.fillText(colLabel(c), x, oy - 16);
    ctx.fillText(colLabel(c), x, oy + ROWS * CELL + 16);
  }
  for (let r = 0; r < ROWS; r++) {
    const y = oy + r * CELL + CELL / 2;
    ctx.fillText(String(r + 1), ox - 20, y);
    ctx.fillText(String(r + 1), ox + COLS * CELL + 20, y);
  }

  return new Promise((resolve, reject) => {
    canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('PNG export failed'))), 'image/png');
  });
}

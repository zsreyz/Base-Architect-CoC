import { grid, app } from './app.js';
import * as db from '../core/storage.js';
import { toExport, parseImport } from '../core/layoutFormat.js';
import { exportPngBlob } from '../core/exportPng.js';
import { PALETTE, EMPTY } from '../core/constants.js';

let current = { id: null, createdAt: 0 };
let timer = null;
let dirty = false;
let loading = false;
let started = false;

/* ---------------------------------------------------------------- toast */
export function toast(message, kind = 'info') {
  const id = Date.now() + Math.random();
  app.setState({ toast: { id, message, kind } });
  setTimeout(() => {
    if (app.getState().toast?.id === id) app.setState({ toast: null });
  }, 2800);
}

/* ------------------------------------------------------------ persistence */
function currentLayout() {
  return {
    id: current.id,
    name: app.getState().name,
    cells: grid.snapshot(),
    createdAt: current.createdAt,
    updatedAt: Date.now(),
  };
}

export async function saveNow() {
  clearTimeout(timer);
  timer = null;
  dirty = false;
  if (!current.id) return;
  app.setState({ saveState: 'saving' });
  try {
    await db.putLayout(currentLayout());
    await db.setMeta('currentId', current.id);
    // A newer edit may have arrived while saving.
    app.setState({ saveState: dirty ? 'dirty' : 'saved', savedAt: Date.now() });
  } catch {
    app.setState({ saveState: 'error' });
  }
}

function scheduleSave() {
  if (loading) return;
  dirty = true;
  app.setState({ saveState: 'dirty' });
  clearTimeout(timer);
  timer = setTimeout(saveNow, 400);
}

export async function refreshLayouts() {
  const all = await db.listLayouts();
  app.setState({
    layouts: all.map((l) => {
      let n = 0;
      for (let i = 0; i < l.cells.length; i++) if (l.cells[i] !== EMPTY) n++;
      return { id: l.id, name: l.name, createdAt: l.createdAt, updatedAt: l.updatedAt, coloured: n };
    }),
  });
}

function applyLayout(l) {
  loading = true;
  current = { id: l.id, createdAt: l.createdAt };
  app.setState({ name: l.name, currentId: l.id, selected: -1, hover: -1, saveState: 'saved' });
  grid.load(l.cells);
  loading = false;
}

export async function init() {
  if (started) return;
  started = true;
  try {
    app.setState({ customColors: (await db.getMeta('customColors')) || [] });
    const all = await db.listLayouts();
    const id = await db.getMeta('currentId');
    let cur = all.find((l) => l.id === id) || all[0];
    if (!cur) {
      cur = db.blankLayout('My first base');
      await db.putLayout(cur);
      await db.setMeta('currentId', cur.id);
    }
    applyLayout(cur);
    await refreshLayouts();
  } catch {
    const l = db.blankLayout('My first base');
    applyLayout(l);
  }
  grid.onChange(scheduleSave);
  const flush = () => {
    if (dirty) saveNow();
  };
  window.addEventListener('pagehide', flush);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') flush();
  });
  app.setState({ ready: true });
  if (!db.isPersistent()) {
    toast('Browser storage is unavailable – use Export JSON to keep your work.', 'error');
  }
}

/* --------------------------------------------------------------- layouts */
export function setName(name) {
  app.setState({ name: name.slice(0, 60) });
  scheduleSave();
}

export async function newLayout() {
  await saveNow();
  const n = app.getState().layouts.length + 1;
  const l = db.blankLayout(`Base ${n}`);
  await db.putLayout(l);
  applyLayout(l);
  await db.setMeta('currentId', l.id);
  await refreshLayouts();
  toast('New layout created');
}

export async function openLayout(id) {
  if (id === current.id) return;
  await saveNow();
  const l = await db.getLayout(id);
  if (!l) return toast('That layout could not be loaded.', 'error');
  applyLayout(l);
  await db.setMeta('currentId', l.id);
  app.setState({ dialog: null });
  toast(`Opened “${l.name}”`);
}

export async function renameLayout(id, name) {
  const clean = name.trim().slice(0, 60);
  if (!clean) return;
  if (id === current.id) {
    app.setState({ name: clean });
    await saveNow();
  } else {
    const l = await db.getLayout(id);
    if (l) await db.putLayout({ ...l, name: clean, updatedAt: Date.now() });
  }
  await refreshLayouts();
}

export async function duplicateLayout(id) {
  if (id === current.id) await saveNow();
  const l = await db.getLayout(id);
  if (!l) return;
  const now = Date.now();
  await db.putLayout({ ...l, id: db.newId(), name: `${l.name} copy`.slice(0, 60), createdAt: now, updatedAt: now });
  await refreshLayouts();
  toast('Layout duplicated');
}

export async function deleteLayoutById(id) {
  await db.deleteLayout(id);
  if (id === current.id) {
    clearTimeout(timer);
    dirty = false;
    const all = await db.listLayouts();
    let next = all[0];
    if (!next) {
      next = db.blankLayout('My first base');
      await db.putLayout(next);
    }
    applyLayout(next);
    await db.setMeta('currentId', next.id);
  }
  await refreshLayouts();
  toast('Layout deleted');
}

/* ----------------------------------------------------------- import/export */
function download(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

const safeName = (n) => n.replace(/[^\w\- ]+/g, '').trim().replace(/\s+/g, '-') || 'layout';

export function exportJsonOf(layout) {
  const json = JSON.stringify(toExport(layout), null, 2);
  download(new Blob([json], { type: 'application/json' }), `${safeName(layout.name)}.json`);
  toast('Layout exported as JSON');
}

export function exportCurrentJson() {
  exportJsonOf(currentLayout());
}

export async function exportJsonById(id) {
  if (id === current.id) return exportCurrentJson();
  const l = await db.getLayout(id);
  if (l) exportJsonOf(l);
}

export async function exportPng() {
  try {
    const blob = await exportPngBlob(grid.cells, app.getState().name);
    download(blob, `${safeName(app.getState().name)}.png`);
    toast('Top-down PNG exported');
  } catch {
    toast('PNG export failed.', 'error');
  }
}

export async function importFile(file) {
  if (!file) return;
  let text;
  try {
    text = await file.text();
  } catch {
    return toast('Could not read that file.', 'error');
  }
  const r = parseImport(text);
  if (!r.ok) return toast(`Import failed: ${r.error}`, 'error');
  await saveNow();
  const l = { id: db.newId(), ...r.layout };
  await db.putLayout(l);
  applyLayout(l);
  await db.setMeta('currentId', l.id);
  await refreshLayouts();
  app.setState({ dialog: null });
  toast(`Imported “${l.name}”`);
}

/* ----------------------------------------------------------------- editing */
export const setTool = (tool) => app.setState({ tool });
export const toggleGrid = () => app.setState({ showGrid: !app.getState().showGrid });
export const undo = () => grid.undo();
export const redo = () => grid.redo();
export const openDialog = (d) => app.setState({ dialog: d });
export const closeDialog = () => app.setState({ dialog: null });

export function requestClear() {
  if (grid.count === 0) return toast('The grid is already empty.');
  openDialog({ type: 'clear' });
}

export function confirmClear() {
  grid.clear();
  closeDialog();
  toast('Grid cleared – press Undo to bring it back');
}

export function pickColor(hex) {
  app.setState({ color: hex, tool: 'paint' });
}

export async function addCustomColor(hex) {
  if (PALETTE.some((p) => p.hex === hex)) return;
  const list = [hex, ...app.getState().customColors.filter((c) => c !== hex)].slice(0, 8);
  app.setState({ customColors: list });
  await db.setMeta('customColors', list);
}

export async function removeCustomColor(hex) {
  const list = app.getState().customColors.filter((c) => c !== hex);
  const s = app.getState();
  app.setState({ customColors: list, color: s.color === hex ? PALETTE[1].hex : s.color });
  await db.setMeta('customColors', list);
}

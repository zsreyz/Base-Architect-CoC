import { useSyncExternalStore } from 'react';
import { createStore } from '../core/createStore.js';
import { Grid } from '../core/grid.js';
import { PALETTE } from '../core/constants.js';

/** The one grid instance for the whole app (single source of truth for cell data). */
export const grid = new Grid();

/** UI state. Cell data is NOT in here, so painting never re-renders the whole UI. */
export const app = createStore({
  tool: 'paint', // 'navigate' | 'paint' | 'erase'
  color: PALETTE[1].hex,
  customColors: [],
  showGrid: true,
  spaceDown: false, // holding Space temporarily switches to navigate (desktop)
  selected: -1,
  hover: -1,
  layouts: [], // summaries: { id, name, updatedAt, createdAt, coloured }
  currentId: null,
  name: 'Untitled base',
  saveState: 'saved', // 'saved' | 'dirty' | 'saving' | 'error'
  savedAt: 0,
  dialog: null, // null | { type:'clear' } | { type:'layouts' } | { type:'delete', id, name }
  toast: null,
  panel: null, // small screens: null | 'stats' | 'camera'
  ready: false,
});

export function useApp(selector) {
  return useSyncExternalStore(app.subscribe, () => selector(app.getState()));
}

export function useGrid(selector) {
  return useSyncExternalStore(grid.status.subscribe, () => selector(grid.status.getState()));
}

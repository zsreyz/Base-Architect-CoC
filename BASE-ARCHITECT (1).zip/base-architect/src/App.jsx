import { Component, useEffect } from 'react';
import Scene from './scene/Scene.jsx';
import TopBar from './ui/TopBar.jsx';
import Toolbar from './ui/Toolbar.jsx';
import StatsPanel from './ui/StatsPanel.jsx';
import BottomBar from './ui/BottomBar.jsx';
import { Dialogs, Toast } from './ui/Dialogs.jsx';
import useShortcuts from './ui/useShortcuts.js';
import { useApp } from './state/app.js';
import { init } from './state/actions.js';

function hasWebGL() {
  try {
    const c = document.createElement('canvas');
    return !!(window.WebGLRenderingContext && (c.getContext('webgl2') || c.getContext('webgl')));
  } catch {
    return false;
  }
}

class Boundary extends Component {
  state = { error: null };
  static getDerivedStateFromError(error) {
    return { error };
  }
  render() {
    if (this.state.error) {
      return (
        <div className="fallback">
          <h2>The 3D view could not start</h2>
          <p>{String(this.state.error.message || this.state.error)}</p>
          <p className="muted">Try reloading the page or enabling hardware acceleration in your browser.</p>
        </div>
      );
    }
    return this.props.children;
  }
}

function Hint() {
  const tool = useApp((s) => s.tool);
  return (
    <div className="hint" aria-hidden="true">
      <span className="fine">
        {tool === 'navigate'
          ? 'Drag: rotate · Right-drag: pan · Wheel: zoom'
          : `Drag: ${tool === 'erase' ? 'erase' : 'paint'} · Right-drag: rotate · Shift+Right-drag / Middle: pan · Wheel: zoom · Hold Space: move camera`}
      </span>
      <span className="coarse">
        {tool === 'navigate'
          ? '1 finger: rotate · 2 fingers: pan & pinch zoom'
          : `1 finger: ${tool === 'erase' ? 'erase' : 'paint'} · 2 fingers: pinch zoom & rotate · Move tool: pan`}
      </span>
    </div>
  );
}

export default function App() {
  const ready = useApp((s) => s.ready);
  useShortcuts();
  useEffect(() => {
    init();
  }, []);

  return (
    <div className="app">
      <TopBar />
      <Toolbar />
      <main className="stage">
        {hasWebGL() ? (
          <Boundary>
            <Scene />
          </Boundary>
        ) : (
          <div className="fallback">
            <h2>WebGL is not available</h2>
            <p className="muted">BASE ARCHITECT needs WebGL to draw the 3D grid.</p>
          </div>
        )}
        {!ready && <div className="loading">Loading layout…</div>}
        <Hint />
      </main>
      <StatsPanel />
      <BottomBar />
      <Dialogs />
      <Toast />
    </div>
  );
}

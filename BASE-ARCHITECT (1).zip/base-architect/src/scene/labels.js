import * as THREE from 'three';
import { COLS, ROWS } from '../core/constants.js';
import { colLabel } from '../core/coords.js';

const CELL = 128;
const PER_ROW = 11;
const HALF = 22;

/**
 * All 88 coordinate labels (A–AR, 1–44) on all four sides of the board, drawn from one
 * canvas atlas into ONE geometry = one draw call. Labels lie flat on the base plate.
 */
export function buildLabels(y) {
  const labels = [];
  for (let c = 0; c < COLS; c++) labels.push(colLabel(c));
  for (let r = 0; r < ROWS; r++) labels.push(String(r + 1));
  const rowsN = Math.ceil(labels.length / PER_ROW);

  const canvas = document.createElement('canvas');
  canvas.width = PER_ROW * CELL;
  canvas.height = rowsN * CELL;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#a3abb8';
  ctx.font = '600 56px system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  labels.forEach((t, i) => {
    ctx.fillText(t, (i % PER_ROW) * CELL + CELL / 2, Math.floor(i / PER_ROW) * CELL + CELL / 2 + 3);
  });

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 8;

  const pos = [];
  const uv = [];
  const idx = [];
  let v = 0;
  const h = 0.42;
  const quad = (x, z, li) => {
    const cx = li % PER_ROW;
    const cy = Math.floor(li / PER_ROW);
    const u0 = cx / PER_ROW;
    const u1 = (cx + 1) / PER_ROW;
    const vt = 1 - cy / rowsN;
    const vb = 1 - (cy + 1) / rowsN;
    // text reads upright when viewed from the south (+z), looking north
    pos.push(x - h, y, z + h, x + h, y, z + h, x + h, y, z - h, x - h, y, z - h);
    uv.push(u0, vb, u1, vb, u1, vt, u0, vt);
    idx.push(v, v + 1, v + 2, v, v + 2, v + 3);
    v += 4;
  };
  for (let c = 0; c < COLS; c++) {
    const x = c - HALF + 0.5;
    quad(x, -HALF - 0.5, c);
    quad(x, HALF + 0.5, c);
  }
  for (let r = 0; r < ROWS; r++) {
    const z = r - HALF + 0.5;
    quad(-HALF - 0.5, z, COLS + r);
    quad(HALF + 0.5, z, COLS + r);
  }

  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  geometry.setIndex(idx);
  return { geometry, texture };
}

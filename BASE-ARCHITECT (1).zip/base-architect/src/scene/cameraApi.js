// Imperative camera API. The <Rig/> inside the Canvas fills these in; UI buttons call them.
// (The camera lives in the WebGL world, so it is not React state.)
const noop = () => {};

export const cameraApi = {
  reset: noop, // animate back to the original view
  view: noop, // view('top' | 'front' | 'back' | 'left' | 'right' | 'under' | 'iso')
  zoomBy: noop, // zoomBy(factor)  <1 zooms in, >1 zooms out
  orbitBy: noop, // orbitBy(dAzimuth, dPolar) in radians
  panBy: noop, // panBy(right, forward) in screen-relative steps (-1..1)
};

import { useEffect, useLayoutEffect, useMemo, useRef } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import { grid, app, useApp } from '../state/app.js';
import { COLS, ROWS, TOTAL, EMPTY, EMPTY_HEX } from '../core/constants.js';
import { lineCells } from '../core/coords.js';
import { cameraApi } from './cameraApi.js';
import { buildLabels } from './labels.js';

const HALF = 22; // board spans x,z in [-22, 22]; cell (col,row) centre = (col-21.5, row-21.5)
const THICK = 0.14; // tile thickness (top face is at y = 0)
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

/* ------------------------------------------------------------------ tiles */
// ONE InstancedMesh draws all 1,936 cells. Painting only rewrites that cell's colour slot.
function Tiles() {
  const mesh = useRef();
  const invalidate = useThree((s) => s.invalidate);
  const showGrid = useApp((s) => s.showGrid);
  const geometry = useMemo(() => {
    const g = new THREE.BoxGeometry(1, THICK, 1);
    g.translate(0, -THICK / 2, 0);
    return g;
  }, []);

  // positions / size (tiles leave a hairline gap when the grid is shown, butt together when hidden)
  useLayoutEffect(() => {
    const m = mesh.current;
    const d = new THREE.Object3D();
    const s = showGrid ? 0.94 : 1.0;
    for (let i = 0; i < TOTAL; i++) {
      d.position.set((i % COLS) - HALF + 0.5, 0, Math.floor(i / COLS) - HALF + 0.5);
      d.scale.set(s, 1, s);
      d.updateMatrix();
      m.setMatrixAt(i, d.matrix);
    }
    m.instanceMatrix.needsUpdate = true;
    invalidate();
  }, [showGrid, invalidate]);

  // colours: initial fill + incremental updates straight from the grid data
  useLayoutEffect(() => {
    const m = mesh.current;
    const c = new THREE.Color();
    const set = (i) => {
      const v = grid.cells[i];
      m.setColorAt(i, c.setHex(v === EMPTY ? EMPTY_HEX : v));
    };
    for (let i = 0; i < TOTAL; i++) set(i);
    m.instanceColor.needsUpdate = true;
    invalidate();
    return grid.onChange((indices) => {
      if (indices === null) for (let i = 0; i < TOTAL; i++) set(i);
      else for (const i of indices) set(i);
      m.instanceColor.needsUpdate = true;
      invalidate();
    });
  }, [invalidate]);

  return (
    <instancedMesh ref={mesh} args={[geometry, undefined, TOTAL]} frustumCulled={false}>
      <meshBasicMaterial polygonOffset polygonOffsetFactor={1} polygonOffsetUnits={1} />
    </instancedMesh>
  );
}

/* ------------------------------------------------------------- grid lines */
function GridLines() {
  const showGrid = useApp((s) => s.showGrid);
  const invalidate = useThree((s) => s.invalidate);
  const { inner, border } = useMemo(() => {
    const y = 0.012;
    const a = [];
    for (let i = 1; i < COLS; i++) {
      const p = i - HALF;
      a.push(p, y, -HALF, p, y, HALF);
    }
    for (let j = 1; j < ROWS; j++) {
      const p = j - HALF;
      a.push(-HALF, y, p, HALF, y, p);
    }
    const b = [-HALF, y, -HALF, HALF, y, -HALF, HALF, y, -HALF, HALF, y, HALF, HALF, y, HALF, -HALF, y, HALF, -HALF, y, HALF, -HALF, y, -HALF];
    const mk = (arr) => {
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.Float32BufferAttribute(arr, 3));
      return g;
    };
    return { inner: mk(a), border: mk(b) };
  }, []);
  useEffect(() => invalidate(), [showGrid, invalidate]);
  return (
    <>
      <lineSegments geometry={inner} visible={showGrid}>
        <lineBasicMaterial color="#5a626f" transparent opacity={0.9} />
      </lineSegments>
      <lineSegments geometry={border}>
        <lineBasicMaterial color="#9aa3b2" />
      </lineSegments>
    </>
  );
}

/* ---------------------------------------------------------- plate + labels */
function Plate() {
  const { geometry, texture } = useMemo(() => buildLabels(-THICK + 0.01), []);
  return (
    <>
      <ambientLight intensity={1.5} />
      <directionalLight position={[20, 40, 25]} intensity={1.1} />
      <mesh position={[0, -THICK - 0.3, 0]}>
        <boxGeometry args={[47, 0.6, 47]} />
        <meshLambertMaterial color="#14161b" />
      </mesh>
      <mesh geometry={geometry}>
        <meshBasicMaterial map={texture} transparent depthWrite={false} toneMapped={false} />
      </mesh>
    </>
  );
}

/* ---------------------------------------------------- hover / selection ring */
function Markers() {
  const invalidate = useThree((s) => s.invalidate);
  const hoverRef = useRef();
  const selRef = useRef();
  const frame = useMemo(() => {
    const o = 0.5;
    const i = 0.4;
    const s = new THREE.Shape();
    s.moveTo(-o, -o);
    s.lineTo(o, -o);
    s.lineTo(o, o);
    s.lineTo(-o, o);
    s.lineTo(-o, -o);
    const hole = new THREE.Path();
    hole.moveTo(-i, -i);
    hole.lineTo(-i, i);
    hole.lineTo(i, i);
    hole.lineTo(i, -i);
    hole.lineTo(-i, -i);
    s.holes.push(hole);
    return new THREE.ShapeGeometry(s);
  }, []);

  useEffect(() => {
    let lastHover = -2;
    let lastSel = -2;
    const place = (mesh, i, y) => {
      if (i < 0) {
        mesh.visible = false;
        return;
      }
      mesh.visible = true;
      mesh.position.set((i % COLS) - HALF + 0.5, y, Math.floor(i / COLS) - HALF + 0.5);
    };
    const sync = (s) => {
      if (s.hover === lastHover && s.selected === lastSel) return;
      lastHover = s.hover;
      lastSel = s.selected;
      place(hoverRef.current, s.hover, 0.02);
      place(selRef.current, s.selected, 0.03);
      invalidate();
    };
    sync(app.getState());
    return app.subscribe(sync);
  }, [invalidate]);

  return (
    <>
      <mesh ref={hoverRef} rotation-x={-Math.PI / 2} visible={false}>
        <planeGeometry args={[1, 1]} />
        <meshBasicMaterial color="#ffffff" transparent opacity={0.28} depthWrite={false} />
      </mesh>
      <mesh ref={selRef} rotation-x={-Math.PI / 2} geometry={frame} visible={false}>
        <meshBasicMaterial color="#f5b83d" side={THREE.DoubleSide} depthWrite={false} />
      </mesh>
    </>
  );
}

/* ---------------------------------------------------- camera rig + input */
const EPS = 0.0005;
const shortest = (d) => ((((d + Math.PI) % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI)) - Math.PI;
const ease = (t) => 1 - Math.pow(1 - t, 3);

function Rig() {
  const { camera, gl, invalidate, get } = useThree();
  const controls = useRef();
  const anim = useRef(null);
  const tool = useApp((s) => s.tool);
  const space = useApp((s) => s.spaceDown);
  const nav = tool === 'navigate' || space;

  // Paint/erase: the primary pointer paints, so the camera uses right-drag (rotate), middle (pan)
  // and two-finger gestures. Navigate: the primary pointer moves the camera.
  const mouseButtons = useMemo(
    () =>
      nav
        ? { LEFT: THREE.MOUSE.ROTATE, MIDDLE: THREE.MOUSE.PAN, RIGHT: THREE.MOUSE.PAN }
        : { LEFT: -1, MIDDLE: THREE.MOUSE.PAN, RIGHT: THREE.MOUSE.ROTATE },
    [nav],
  );
  const touches = useMemo(
    () =>
      nav
        ? { ONE: THREE.TOUCH.ROTATE, TWO: THREE.TOUCH.DOLLY_PAN }
        : { ONE: -1, TWO: THREE.TOUCH.DOLLY_ROTATE },
    [nav],
  );

  /* ---- camera helpers ---- */
  useEffect(() => {
    const sph = new THREE.Spherical();
    const tmp = new THREE.Vector3();
    const right = new THREE.Vector3();
    const fwd = new THREE.Vector3();

    const read = () => {
      const c = controls.current;
      tmp.copy(camera.position).sub(c.target);
      sph.setFromVector3(tmp);
      return { r: sph.radius, phi: sph.phi, theta: sph.theta, target: c.target.clone() };
    };
    const apply = (v) => {
      const c = controls.current;
      c.target.copy(v.target);
      sph.set(v.r, clamp(v.phi, EPS, Math.PI - EPS), v.theta);
      tmp.setFromSpherical(sph);
      camera.position.copy(c.target).add(tmp);
      camera.lookAt(c.target);
      c.update();
      invalidate();
    };
    const home = () => {
      const { width, height } = get().size;
      const aspect = width / Math.max(1, height);
      return {
        r: Math.min(150, 56 * Math.max(1, 1.1 / aspect)),
        phi: 0.87,
        theta: 0,
        target: new THREE.Vector3(0, 0, 0),
      };
    };
    const animateTo = (to) => {
      anim.current = { from: read(), to, t: 0, dur: 0.55 };
      invalidate();
    };

    apply(home());

    cameraApi.reset = () => animateTo(home());
    cameraApi.view = (name) => {
      const h = home();
      const t = new THREE.Vector3();
      const views = {
        iso: { phi: h.phi, theta: 0 },
        top: { phi: EPS, theta: 0 },
        front: { phi: 1.25, theta: 0 },
        back: { phi: 1.25, theta: Math.PI },
        left: { phi: 1.25, theta: -Math.PI / 2 },
        right: { phi: 1.25, theta: Math.PI / 2 },
        under: { phi: Math.PI - 0.45, theta: 0 },
      };
      const v = views[name] || views.iso;
      animateTo({ r: h.r, phi: v.phi, theta: v.theta, target: t });
    };
    cameraApi.zoomBy = (f) => {
      anim.current = null;
      const v = read();
      v.r = clamp(v.r * f, controls.current.minDistance, controls.current.maxDistance);
      apply(v);
    };
    cameraApi.orbitBy = (dTheta, dPhi) => {
      anim.current = null;
      const v = read();
      v.theta += dTheta;
      v.phi += dPhi;
      apply(v);
    };
    cameraApi.panBy = (r, f) => {
      anim.current = null;
      const c = controls.current;
      const dist = camera.position.distanceTo(c.target);
      right.setFromMatrixColumn(camera.matrix, 0);
      right.y = 0;
      right.normalize();
      // screen-up projected on the ground = "forward"
      fwd.setFromMatrixColumn(camera.matrix, 1);
      fwd.y = 0;
      if (fwd.lengthSq() < 1e-4) fwd.setFromMatrixColumn(camera.matrix, 2).negate().setY(0);
      fwd.normalize();
      const k = dist * 0.02;
      tmp.set(0, 0, 0).addScaledVector(right, r * k).addScaledVector(fwd, f * k);
      camera.position.add(tmp);
      c.target.add(tmp);
      c.update();
      invalidate();
    };
    cameraApi.__anim = anim;
    cameraApi.__read = read;
    cameraApi.__apply = apply;
    return () => {
      cameraApi.reset = cameraApi.view = cameraApi.zoomBy = cameraApi.orbitBy = cameraApi.panBy = () => {};
    };
  }, [camera, invalidate, get]);

  // tween driver
  useFrame((_, dt) => {
    const a = anim.current;
    if (!a) return;
    a.t = Math.min(1, a.t + dt / a.dur);
    const k = ease(a.t);
    const lerp = (x, y) => x + (y - x) * k;
    cameraApi.__apply({
      r: lerp(a.from.r, a.to.r),
      phi: lerp(a.from.phi, a.to.phi),
      theta: a.from.theta + shortest(a.to.theta - a.from.theta) * k,
      target: a.from.target.clone().lerp(a.to.target, k),
    });
    if (a.t >= 1) anim.current = null;
    else invalidate();
  });

  // keep the look-at point inside a sensible box, cancel tweens when the user grabs the camera
  useEffect(() => {
    const c = controls.current;
    const delta = new THREE.Vector3();
    const onChange = () => {
      const t = c.target;
      delta.set(clamp(t.x, -45, 45) - t.x, clamp(t.y, -6, 6) - t.y, clamp(t.z, -45, 45) - t.z);
      if (delta.lengthSq() > 0) {
        t.add(delta);
        camera.position.add(delta);
      }
    };
    const onStart = () => {
      anim.current = null;
    };
    c.addEventListener('change', onChange);
    c.addEventListener('start', onStart);
    return () => {
      c.removeEventListener('change', onChange);
      c.removeEventListener('start', onStart);
    };
  }, [camera]);

  /* ---- picking + painting (ray / plane intersection) ---- */
  useEffect(() => {
    const dom = gl.domElement;
    const raycaster = new THREE.Raycaster();
    const ndc = new THREE.Vector2();
    const plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0); // y = 0, the tile tops
    const hit = new THREE.Vector3();

    const cellAt = (clientX, clientY) => {
      const r = dom.getBoundingClientRect();
      ndc.set(((clientX - r.left) / r.width) * 2 - 1, -((clientY - r.top) / r.height) * 2 + 1);
      camera.updateMatrixWorld();
      raycaster.setFromCamera(ndc, camera);
      if (!raycaster.ray.intersectPlane(plane, hit)) return -1;
      const col = Math.floor(hit.x + HALF);
      const row = Math.floor(hit.z + HALF);
      if (col < 0 || col >= COLS || row < 0 || row >= ROWS) return -1;
      return row * COLS + col;
    };

    const pointers = new Set();
    let stroking = false;
    let strokeId = -1;
    let last = -1;
    let value = EMPTY;
    let gesture = false; // a multi-touch camera gesture is in progress: never paint
    let tap = null;

    const isNav = () => {
      const s = app.getState();
      return s.tool === 'navigate' || s.spaceDown;
    };
    const stamp = (i) => {
      grid.paint(i, value);
      app.setState({ selected: i });
    };

    const down = (e) => {
      pointers.add(e.pointerId);
      if (pointers.size > 1) {
        // second finger: this is a camera gesture, undo any accidental first-touch paint
        if (stroking) {
          grid.cancelStroke();
          stroking = false;
        }
        gesture = true;
        tap = null;
        return;
      }
      gesture = false;
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      if (isNav()) {
        tap = { id: e.pointerId, x: e.clientX, y: e.clientY, t: performance.now() };
        return;
      }
      const idx = cellAt(e.clientX, e.clientY);
      const s = app.getState();
      value = s.tool === 'erase' ? EMPTY : s.color;
      stroking = true;
      strokeId = e.pointerId;
      last = -1;
      grid.beginStroke();
      if (idx >= 0) {
        stamp(idx);
        last = idx;
      }
    };

    const move = (e) => {
      if (e.pointerType === 'mouse' && !stroking) {
        const idx = cellAt(e.clientX, e.clientY);
        if (idx !== app.getState().hover) app.setState({ hover: idx });
      }
      if (!stroking || e.pointerId !== strokeId || gesture) return;
      const evs = e.getCoalescedEvents ? e.getCoalescedEvents() : [];
      for (const ev of evs.length ? evs : [e]) {
        const idx = cellAt(ev.clientX, ev.clientY);
        if (idx < 0) {
          last = -1;
          continue;
        }
        if (idx === last) continue;
        if (last < 0) stamp(idx);
        else for (const c of lineCells(last, idx)) stamp(c); // no gaps on fast drags
        last = idx;
      }
      if (e.pointerType === 'mouse') app.setState({ hover: last });
    };

    const up = (e) => {
      pointers.delete(e.pointerId);
      if (stroking && e.pointerId === strokeId) {
        grid.endStroke();
        stroking = false;
      } else if (tap && tap.id === e.pointerId && !gesture) {
        const moved = Math.hypot(e.clientX - tap.x, e.clientY - tap.y);
        if (moved < 8 && performance.now() - tap.t < 600) {
          const idx = cellAt(e.clientX, e.clientY);
          app.setState({ selected: idx });
        }
      }
      if (e.pointerId === (tap && tap.id)) tap = null;
      if (pointers.size === 0) gesture = false;
    };

    const cancel = (e) => {
      pointers.delete(e.pointerId);
      if (stroking && e.pointerId === strokeId) {
        grid.cancelStroke();
        stroking = false;
      }
      tap = null;
      if (pointers.size === 0) gesture = false;
    };

    const leave = (e) => {
      if (e.pointerType === 'mouse' && !stroking) app.setState({ hover: -1 });
    };
    const blur = () => {
      if (stroking) {
        grid.endStroke();
        stroking = false;
      }
    };
    const noMenu = (e) => e.preventDefault();

    dom.addEventListener('pointerdown', down);
    dom.addEventListener('pointermove', move);
    dom.addEventListener('pointerup', up);
    dom.addEventListener('pointercancel', cancel);
    dom.addEventListener('pointerleave', leave);
    dom.addEventListener('contextmenu', noMenu);
    window.addEventListener('blur', blur);
    return () => {
      dom.removeEventListener('pointerdown', down);
      dom.removeEventListener('pointermove', move);
      dom.removeEventListener('pointerup', up);
      dom.removeEventListener('pointercancel', cancel);
      dom.removeEventListener('pointerleave', leave);
      dom.removeEventListener('contextmenu', noMenu);
      window.removeEventListener('blur', blur);
    };
  }, [camera, gl]);

  useEffect(() => {
    gl.domElement.style.cursor = nav ? 'grab' : tool === 'erase' ? 'cell' : 'crosshair';
  }, [gl, nav, tool]);

  return (
    <OrbitControls
      ref={controls}
      makeDefault
      enableDamping
      dampingFactor={0.12}
      rotateSpeed={0.7}
      panSpeed={0.9}
      zoomSpeed={0.9}
      minDistance={5}
      maxDistance={160}
      screenSpacePanning={false}
      mouseButtons={mouseButtons}
      touches={touches}
    />
  );
}

/* ------------------------------------------------------------------ canvas */
export default function Scene() {
  return (
    <Canvas
      frameloop="demand"
      dpr={[1, 2]}
      gl={{ antialias: true }}
      camera={{ fov: 40, near: 0.5, far: 500, position: [0, 34, 36] }}
    >
      <color attach="background" args={['#16181c']} />
      <Plate />
      <Tiles />
      <GridLines />
      <Markers />
      <Rig />
    </Canvas>
  );
}

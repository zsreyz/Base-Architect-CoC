import test from 'node:test';
import assert from 'node:assert/strict';
import * as db from '../src/core/storage.js';
import { TOTAL, EMPTY } from '../src/core/constants.js';

// Node has no IndexedDB, so these exercise the same API through the in-memory fallback.
test('layouts can be created, listed, updated, fetched and deleted', async () => {
  const a = db.blankLayout('Alpha');
  a.cells[3] = 0xff0000;
  a.cells[4] = 0; // black must survive storage
  await db.putLayout(a);
  const b = db.blankLayout('Beta');
  b.updatedAt = a.updatedAt + 5;
  await db.putLayout(b);

  const all = await db.listLayouts();
  assert.equal(all.length, 2);
  assert.equal(all[0].name, 'Beta', 'newest first');

  const got = await db.getLayout(a.id);
  assert.equal(got.cells.length, TOTAL);
  assert.equal(got.cells[3], 0xff0000);
  assert.equal(got.cells[4], 0);
  assert.equal(got.cells[5], EMPTY);

  // returned copies are independent of storage
  got.cells[3] = 1;
  assert.equal((await db.getLayout(a.id)).cells[3], 0xff0000);

  await db.putLayout({ ...a, name: 'Alpha renamed' });
  assert.equal((await db.getLayout(a.id)).name, 'Alpha renamed');

  await db.deleteLayout(a.id);
  assert.equal(await db.getLayout(a.id), null);
  assert.equal((await db.listLayouts()).length, 1);
});

test('meta values round-trip', async () => {
  await db.setMeta('currentId', 'abc');
  assert.equal(await db.getMeta('currentId'), 'abc');
  await db.setMeta('customColors', [1, 2, 3]);
  assert.deepEqual(await db.getMeta('customColors'), [1, 2, 3]);
});

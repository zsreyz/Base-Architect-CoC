import test from 'node:test';
import assert from 'node:assert/strict';
import { Grid } from '../src/core/grid.js';
import { COLS, ROWS, TOTAL, EMPTY } from '../src/core/constants.js';
import { colLabel, cellName, parseCoord, lineCells } from '../src/core/coords.js';
import { stats, formatPct } from '../src/core/stats.js';
import { toExport, parseImport } from '../src/core/layoutFormat.js';

const RED = 0xe5484d;
const BLUE = 0x3b82f6;
const BLACK = 0x000000;

function consistent(g) {
  assert.equal(g.count, g.countActual(), 'incremental count must equal real data');
  assert.equal(g.status.getState().coloured, g.count);
}

test('grid is exactly 44 x 44 = 1,936 cells, all empty', () => {
  const g = new Grid();
  assert.equal(COLS, 44);
  assert.equal(ROWS, 44);
  assert.equal(TOTAL, 1936);
  assert.equal(g.cells.length, 1936);
  assert.equal(g.count, 0);
  consistent(g);
});

test('coordinates: A–AR, rows 1–44, all 1,936 unique', () => {
  assert.equal(colLabel(0), 'A');
  assert.equal(colLabel(25), 'Z');
  assert.equal(colLabel(26), 'AA');
  assert.equal(colLabel(43), 'AR');
  assert.equal(cellName(0), 'A1');
  assert.equal(cellName(TOTAL - 1), 'AR44');
  assert.equal(cellName(2 * COLS + 11), 'C12' === 'C12' ? cellName(2 * COLS + 11) : '');
  assert.equal(parseCoord('C12').index, 11 * COLS + 2);
  assert.equal(parseCoord('AR44').index, TOTAL - 1);
  assert.equal(parseCoord('AS1'), null);
  assert.equal(parseCoord('A45'), null);
  assert.equal(parseCoord('A0'), null);
  assert.equal(parseCoord('nope'), null);
  const names = new Set();
  for (let i = 0; i < TOTAL; i++) {
    const n = cellName(i);
    names.add(n);
    assert.equal(parseCoord(n).index, i, 'round trip ' + n);
  }
  assert.equal(names.size, TOTAL);
});

test('painting counts once; recolouring does not change count; erase decrements', () => {
  const g = new Grid();
  assert.equal(g.paint(5, RED), true);
  assert.equal(g.count, 1);
  assert.equal(g.paint(5, RED), false); // same cell, same colour: no duplicate
  assert.equal(g.paint(5, RED), false);
  assert.equal(g.count, 1);
  assert.equal(g.paint(5, BLUE), true); // recolour
  assert.equal(g.count, 1);
  assert.equal(g.cells[5], BLUE);
  assert.equal(g.paint(5, EMPTY), true); // erase
  assert.equal(g.count, 0);
  assert.equal(g.paint(5, EMPTY), false); // erasing empty cell is a no-op
  assert.equal(g.count, 0);
  consistent(g);
});

test('black (0x000000) is a real colour, distinct from empty', () => {
  const g = new Grid();
  g.paint(7, BLACK);
  assert.equal(g.count, 1);
  assert.equal(g.cells[7], 0);
  assert.notEqual(g.cells[7], EMPTY);
  consistent(g);
});

test('out-of-range paints are ignored', () => {
  const g = new Grid();
  assert.equal(g.paint(-1, RED), false);
  assert.equal(g.paint(TOTAL, RED), false);
  assert.equal(g.paint(1.5, RED), false);
  assert.equal(g.count, 0);
});

test('stroke = one undo step; undo/redo restore exact state', () => {
  const g = new Grid();
  g.paint(1, RED); // own stroke #1
  g.beginStroke();
  for (let i = 10; i < 20; i++) g.paint(i, BLUE);
  g.paint(1, BLUE); // recolour inside a stroke
  g.endStroke();
  assert.equal(g.count, 11);
  const after = g.snapshot();

  assert.ok(g.undo());
  assert.equal(g.count, 1);
  assert.equal(g.cells[1], RED, 'recoloured cell returns to previous colour');
  assert.equal(g.cells[10], EMPTY);
  consistent(g);

  assert.ok(g.redo());
  assert.deepEqual(g.snapshot(), after);
  consistent(g);

  assert.ok(g.undo());
  assert.ok(g.undo());
  assert.equal(g.count, 0);
  assert.equal(g.undo(), false);
  assert.ok(g.redo());
  assert.equal(g.cells[1], RED);
});

test('new edit after undo clears the redo stack', () => {
  const g = new Grid();
  g.paint(1, RED);
  g.paint(2, RED);
  g.undo();
  assert.equal(g.status.getState().canRedo, true);
  g.paint(3, BLUE);
  assert.equal(g.status.getState().canRedo, false);
  assert.equal(g.redo(), false);
  consistent(g);
});

test('a stroke that changes nothing creates no history entry', () => {
  const g = new Grid();
  g.paint(1, RED);
  const depth = g.undoStack.length;
  g.beginStroke();
  g.paint(1, RED);
  g.endStroke();
  assert.equal(g.undoStack.length, depth);
});

test('paint then erase the same cell in one stroke leaves no history', () => {
  const g = new Grid();
  g.beginStroke();
  g.paint(3, RED);
  g.paint(3, EMPTY);
  g.endStroke();
  assert.equal(g.undoStack.length, 0);
  assert.equal(g.count, 0);
});

test('cancelStroke rolls back everything the stroke touched', () => {
  const g = new Grid();
  g.paint(1, RED);
  g.beginStroke();
  g.paint(1, BLUE);
  g.paint(2, BLUE);
  g.cancelStroke();
  assert.equal(g.cells[1], RED);
  assert.equal(g.cells[2], EMPTY);
  assert.equal(g.count, 1);
  assert.equal(g.undoStack.length, 1);
  consistent(g);
});

test('clear is one undoable step and zeroes the count', () => {
  const g = new Grid();
  for (let i = 0; i < 200; i++) g.paint(i, RED);
  assert.equal(g.count, 200);
  assert.ok(g.clear());
  assert.equal(g.count, 0);
  consistent(g);
  assert.equal(g.clear(), false);
  assert.ok(g.undo());
  assert.equal(g.count, 200);
  consistent(g);
});

test('rapid painting of all cells never loses an update', () => {
  const g = new Grid();
  g.beginStroke();
  for (let i = 0; i < TOTAL; i++) g.paint(i, i % 2 ? RED : BLUE);
  g.endStroke();
  assert.equal(g.count, TOTAL);
  consistent(g);
  g.undo();
  assert.equal(g.count, 0);
});

test('stats match the spec example: 200 coloured -> 1,736 empty, 10.33%', () => {
  const s = stats(200);
  assert.equal(s.total, 1936);
  assert.equal(s.empty, 1736);
  assert.equal(formatPct(s.pct), '10.33%');
  assert.equal(formatPct(stats(0).pct), '0%');
  assert.equal(formatPct(stats(TOTAL).pct), '100%');
});

test('change listeners receive indices; status store publishes', () => {
  const g = new Grid();
  const seen = [];
  g.onChange((idx) => seen.push(idx));
  g.paint(4, RED);
  assert.deepEqual(seen[0], [4]);
  g.clear();
  assert.equal(seen.at(-1), null);
});

test('lineCells fills gaps between fast pointer events', () => {
  assert.deepEqual(lineCells(0, 3), [1, 2, 3]);
  const diag = lineCells(0, 3 * COLS + 3);
  assert.equal(diag.at(-1), 3 * COLS + 3);
  assert.equal(diag.length, 3);
  assert.deepEqual(lineCells(5, 5), []);
});

test('export -> import round trip preserves every cell, name and metadata', () => {
  const g = new Grid();
  g.paint(0, RED);
  g.paint(TOTAL - 1, BLACK);
  g.paint(500, 0xabcdef);
  const layout = { name: 'My Base', cells: g.snapshot(), createdAt: 1000, updatedAt: 2000 };
  const exported = toExport(layout);
  assert.equal(exported.cells.length, TOTAL);
  assert.equal(exported.cells[0].coord, 'A1');
  assert.equal(exported.cells[0].color, '#e5484d');
  assert.equal(exported.cells[TOTAL - 1].coord, 'AR44');
  assert.equal(exported.cells[TOTAL - 1].color, '#000000');
  assert.equal(exported.cells[1].color, null);
  assert.deepEqual(exported.grid, { columns: 44, rows: 44, totalCells: 1936 });
  assert.equal(exported.metadata.colouredCells, 3);
  assert.equal(exported.metadata.emptyCells, 1933);

  const r = parseImport(JSON.stringify(exported));
  assert.equal(r.ok, true, r.error);
  assert.equal(r.layout.name, 'My Base');
  assert.equal(r.layout.createdAt, 1000);
  assert.deepEqual(r.layout.cells, layout.cells);
});

test('import rejects invalid input safely (never throws)', () => {
  const good = toExport({ name: 'x', cells: new Int32Array(TOTAL).fill(EMPTY), createdAt: 1, updatedAt: 1 });
  const bad = [
    '',
    'not json',
    '[]',
    'null',
    '42',
    '{}',
    JSON.stringify({ ...good, format: 'other' }),
    JSON.stringify({ ...good, version: 99 }),
    JSON.stringify({ ...good, version: 'x' }),
    JSON.stringify({ ...good, grid: { columns: 10, rows: 10 } }),
    JSON.stringify({ ...good, cells: 'nope' }),
    JSON.stringify({ ...good, cells: [{ coord: 'ZZ99', color: '#ffffff' }] }),
    JSON.stringify({ ...good, cells: [{ coord: 'A1', color: 'red' }] }),
    JSON.stringify({ ...good, cells: [{ coord: 'A1', color: '#fff' }, null] }),
    JSON.stringify({ ...good, cells: [{ coord: 'A1', color: '#ffffff' }, { coord: 'A1', color: '#000000' }] }),
    JSON.stringify({ ...good, cells: new Array(TOTAL + 1).fill({ coord: 'A1', color: null }) }),
    undefined,
    123,
    { a: 1 },
  ];
  for (const b of bad) {
    const r = parseImport(b);
    assert.equal(r.ok, false, 'should reject: ' + String(b).slice(0, 40));
    assert.equal(typeof r.error, 'string');
  }
});

test('import tolerates missing name/metadata and sparse cell lists', () => {
  const r = parseImport(
    JSON.stringify({
      format: 'base-architect-layout',
      version: 1,
      grid: { columns: 44, rows: 44 },
      cells: [{ coord: 'b2', color: '#FF0000' }],
    }),
  );
  assert.equal(r.ok, true);
  assert.equal(r.layout.name, 'Imported layout');
  assert.equal(r.layout.cells[1 * COLS + 1], 0xff0000);
  assert.equal(r.layout.cells.filter((v) => v !== EMPTY).length, 1);
});

test('load() replaces grid, recounts, and resets history', () => {
  const g = new Grid();
  g.paint(1, RED);
  const cells = new Int32Array(TOTAL).fill(EMPTY);
  cells[10] = BLUE;
  cells[11] = BLACK;
  g.load(cells);
  assert.equal(g.count, 2);
  assert.equal(g.status.getState().canUndo, false);
  consistent(g);
  assert.throws(() => g.load(new Int32Array(5)));
});

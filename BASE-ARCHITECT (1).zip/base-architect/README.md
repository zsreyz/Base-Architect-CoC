# BASE ARCHITECT

A 3D, 44 × 44 grid designer for planning Clash of Clans village layouts. Paint, erase and recolour 1,936 tiles on a real WebGL board you can orbit, pan and zoom. Built with React, Three.js and React Three Fiber.

## Run it

Requires Node 18+.

```bash
npm install
npm run dev        # http://localhost:5173  (also reachable from a phone on the same Wi-Fi)
npm run build      # production build in dist/
npm run preview    # serve the production build
npm test           # logic tests (grid, undo/redo, stats, import/export, storage)
```

## Folder structure

```
base-architect/
├─ index.html
├─ package.json
├─ vite.config.js
├─ tests/
│  ├─ core.test.js          grid, counts, undo/redo, coordinates, import/export
│  └─ storage.test.js       layout storage API
└─ src/
   ├─ main.jsx  App.jsx  styles.css
   ├─ core/                 pure logic, no React / DOM (unit-tested)
   │  ├─ constants.js       44 × 44, palette
   │  ├─ grid.js            cell data + live count + undo/redo (single source of truth)
   │  ├─ coords.js          A–AR / 1–44 naming, Bresenham line fill
   │  ├─ stats.js  color.js  createStore.js
   │  ├─ layoutFormat.js    JSON export + safe, validating import
   │  ├─ storage.js         IndexedDB (in-memory fallback)
   │  └─ exportPng.js       top-down PNG
   ├─ state/
   │  ├─ app.js             UI store + hooks
   │  └─ actions.js         save / open / rename / import / export / clear
   ├─ scene/
   │  ├─ Scene.jsx          InstancedMesh tiles, grid lines, camera rig, picking & painting
   │  ├─ cameraApi.js       imperative camera API used by the buttons
   │  └─ labels.js          coordinate labels (one draw call)
   └─ ui/                   TopBar, Toolbar (+palette), StatsPanel, BottomBar, Dialogs, shortcuts
```

## Controls

| | Desktop | Touch |
|---|---|---|
| Paint / erase | Left-drag with the Paint / Eraser tool | One finger |
| Rotate | Right-drag (or Move tool + left-drag) | Two fingers (or Move tool + one finger) |
| Pan | Middle-drag, Shift + right-drag, arrow keys, or Move tool + right-drag | Move tool + two fingers, or the Pan buttons |
| Zoom | Mouse wheel, `+` / `-` | Pinch |
| Move camera temporarily | Hold **Space** | Switch to the Move tool |
| Select a cell | Hover (coordinate shown), or click with the Move tool | Tap with the Move tool |

Keys: `B` paint · `E` eraser · `V` move · `G` grid lines · `R` reset camera · `1–9, 0` palette · `Ctrl+Z` undo · `Ctrl+Y` / `Ctrl+Shift+Z` redo · `Ctrl+S` save.

The bottom bar has hold-to-repeat Orbit, Pan and Zoom buttons, preset views (Iso, Top, Front, Back, Left, Right, Under) and Reset view. On small screens the statistics and camera panels open from the top bar.

## How it works

- **Rendering:** one `InstancedMesh` draws all 1,936 tiles with per-instance colours. Painting rewrites only the touched cells' colour slots; React never re-renders the scene when you paint. The canvas renders on demand.
- **Picking:** each pointer position is cast as a ray and intersected with the board plane, which gives the exact cell. Fast drags are filled with a line walk, so no cells are skipped. Coalesced pointer events are used for high-rate input.
- **No accidental painting:** the primary pointer paints in Paint/Eraser mode and moves the camera in Move mode. A second finger cancels the stroke in progress and rolls back anything it touched.
- **Statistics:** the coloured count is updated only on real changes (same-colour repaint and erasing an empty cell are no-ops), and tests check it against a recount of the data.
- **Undo / redo:** one drag is one undo step. Clear is one undoable step. Up to 100 steps are kept.
- **Persistence:** layouts auto-save to IndexedDB about 0.4 s after your last edit and reload on refresh. Several layouts can be created, opened, renamed, duplicated and deleted from **Layouts**.
- **Export / import:** JSON contains the grid size, layout name, metadata and every cell (`"A1"` … `"AR44"`) with its colour or `null`. Import validates the file and rejects bad JSON with a message instead of crashing. PNG export is a flat top-down image with coordinates.

## Notes

- Tested logic: `npm test` runs 21 tests. The 3D scene and UI need a browser; see the manual checklist below.
- Manual checklist: paint and drag; recolour a cell and confirm the count does not change; erase; undo/redo; clear → confirm → undo; rotate, pan and zoom without painting; refresh and confirm the layout is still there; export JSON, import it back; export PNG; try importing a non-layout JSON file.

## License

Copyright (c) 2026 kxvior. Released under the MIT License (see [LICENSE](LICENSE)).

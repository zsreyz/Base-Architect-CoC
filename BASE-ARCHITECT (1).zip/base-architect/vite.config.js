import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  base: './',
  plugins: [react()],
  // host: true lets you open the dev server from an Android phone / tablet on the same Wi-Fi.
  server: { host: true, port: 5173 },
});
